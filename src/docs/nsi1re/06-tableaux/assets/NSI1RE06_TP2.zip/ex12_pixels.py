import images

pixels = [
    [1, 0, 1],
    [0, 1, 1],
    [1, 1, 0],
]

images.afficher_image(pixels)
