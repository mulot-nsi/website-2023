import images


def afficher_dimensions(image):
    """
    Affiche les dimensions de l'image passée en paramètre sous la forme "largeur x hauteur"

    Paramètres :
    image - Tableau à deux dimensions représentant les pixels d'une image

    Tests :
    >>> afficher_dimensions([[0, 0, 0], [0, 0, 0]])
    3 x 2
    >>> afficher_dimensions([[0, 0], [0, 0], [0, 0]])
    2 x 3
    """
    print(len(image[0]), 'x', len(image))


def dessiner_bordure(image):
    """
    Ajoute une bordure à l'image passée en paramètre

    Paramètres :
    image - Tableau à deux dimensions représentant les pixels d'une image

    Tests :
    >>> pixels = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]
    >>> dessiner_bordure(pixels)
    >>> pixels
    [[1, 1, 1], [1, 0, 1], [1, 1, 1]]
    >>> pixels = [[0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0]]
    >>> dessiner_bordure(pixels)
    >>> pixels
    [[1, 1, 1, 1], [1, 0, 0, 1], [1, 0, 0, 1], [1, 0, 0, 1], [1, 1, 1, 1]]
    """
    for ligne in range(len(image)):
        # Cas de la première ligne. Affecter 1 partout.
        if ligne == 0:
            for colonne in range(len(image[ligne])):
                image[ligne][colonne] = 1

        # Cas de la dernière ligne. Affecter 1 partout.
        elif ligne == len(image) - 1:
            for colonne in range(len(image[ligne])):
                image[ligne][colonne] = 1

        # Sinon, affecter 1 au premier et dernier élément.
        else:
            image[ligne][0] = 1
            image[ligne][len(image[ligne]) - 1] = 1


if __name__ == "__main__":
    import doctest

    doctest.testmod()
