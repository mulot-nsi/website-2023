def compter(valeur, tableau):
    """
    Renvoie le nombre d'occurrences d'une valeur dans un tableau.

    Paramètres:
        valeur  -- la valeur dont on souhaite obtenir le nombre d'occurrences
        tableau -- le tableau dans lequel effectuer le comptage

    Tests:
    >>> compter("A", [])
    0
    >>> compter("A", ["C", "D", "E"])
    0
    >>> compter("A", ["A", "B", "C"])
    1
    >>> compter("A", ["A", "C", "A"])
    2
    """
    pass


if __name__ == "__main__":
    import doctest

    doctest.testmod()
