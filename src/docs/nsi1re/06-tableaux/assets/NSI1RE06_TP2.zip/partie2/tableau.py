def comparer(tableau1, tableau2):
    """
    Renvoie vrai si les tableaux sont identiques

    Paramètres :
    tableau1 -- Premier tableau
    tableau2 -- Second tableau

    Tests:
    >>> comparer([1], [1, 2])
    False
    >>> comparer([1, 2], [1, 2])
    True
    >>> comparer([2, 1], [1, 2])
    False
    """
    pass


if __name__ == "__main__":
    import doctest

    doctest.testmod()
