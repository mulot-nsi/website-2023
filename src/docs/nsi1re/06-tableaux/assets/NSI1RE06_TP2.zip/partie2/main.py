import base64
import tableau

secret = [int(v) for v in base64.b64decode("NSwyLDE=").decode("utf8").split(",")]
