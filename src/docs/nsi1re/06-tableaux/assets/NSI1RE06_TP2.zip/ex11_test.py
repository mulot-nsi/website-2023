import images

images.afficher_test()
