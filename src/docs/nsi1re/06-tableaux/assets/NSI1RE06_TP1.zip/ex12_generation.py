# [NSI1RE06] TP1 - Exercice 1.2 - Génération d'un tableau
# Première expression
print([0] * 4)

# Seconde expression
print([0, 1] * 4)

# Conclusion :
#
#