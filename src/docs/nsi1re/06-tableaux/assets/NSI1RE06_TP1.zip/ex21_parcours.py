# [NSI1RE06] TP1 - Exercice 2.1 - Parcours simples
t1 = ['(\\(\\','(-.-)','c(")(")']
t2 = ["'___'","(0,0)","/)_)",' ""']
t3 = ["  __", "<(o )___", " ( ._> /", "  `---'"]

# Tableau t1 : Afficher chaque valeur en utilisant un parcours par valeur.
print("Tableau T1")



# Tableau t2 : Afficher chaque valeur en utilisant un parcours par indice via une boucle bornée.
print("\nTableau T2")



# Tableau t3 : Afficher chaque valeur en utilisant un parcours par indice via une non boucle bornée.
print("\nTableau T3")


