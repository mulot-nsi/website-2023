# [NSI1RE06] TP1 - Exercice 2
# Première expression
print([0] * 4)

# Seconde expression
print([0, 1] * 4)

# Conclusion :
#
#