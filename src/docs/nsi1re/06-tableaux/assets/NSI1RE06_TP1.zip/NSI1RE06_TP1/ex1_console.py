# [NSI1RE06] TP1 - Exercice 1
# Écrire l'instruction ou l'expression saisie dans la console Python pour...

# Affecter le tableau


# Obtenir la valeur du tableau


# Obtenir la taille du tableau


# Obtenir la valeur du premier élément du tableau


# Obtenir la valeur d'indice 2 du tableau


# Obtenir la valeur du 4ème élément du tableau


# Obtenir la valeur du dernier élément du tableau


# Affecter 101 au premier élément du tableau
