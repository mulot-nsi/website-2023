# Implémenter la fonction rapport

if __name__ == '__main__':
    # Températures mensuelles moyennes de l'année 2021
    temperatures_2021 = []

    # Affichage du rapport
