# [NSI1RE06] TP1 - Exercice 1.1 - Expérimentation
# Écrire l'instruction ou l'expression saisie dans la console Python pour ...

# 1. Créer le tableau des nombres premiers


# 2. Vérifier le contenu de la variable stockant le tableau


# 3. Récupérer la taille du tableau


# 4. Récupérer la valeur du premier élément du tableau


# 5. Récupérer la valeur d'indice 2 du tableau


# 6. Récupérer la valeur du 4ème élément du tableau


# 7. Récupérer la valeur du dernier élément du tableau en utilisant len()


# 8. Affecter 101 au premier élément du tableau
