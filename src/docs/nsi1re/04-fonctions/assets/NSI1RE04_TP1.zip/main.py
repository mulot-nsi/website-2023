import turtle
import paysage_absolu as paysage

# Configuration de turtle.
turtle.speed(0)

# Tracé du paysage.
paysage.dessiner_paysage()

# Boucle des événements.
turtle.mainloop()