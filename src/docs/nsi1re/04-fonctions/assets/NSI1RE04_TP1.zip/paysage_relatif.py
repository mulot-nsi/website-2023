from re import A
import turtle
import math
import aide


def mur(largeur, hauteur):
    """
    Dessine le mur d'une maison depuis le coin inférieur gauche dans le sens horaire.
    
    largeur -- largeur du mur
    hauteur -- hauteur du mur
    """
    pass
    
    
def toit(base, hauteur):
    """
    Dessine le toit d'une maison depuis le coin inférieur gauche dans le sens horaire.
    
    base    -- largeur de la base du toit
    hauteur -- hauteur du toit
    """
    
    #    B  
    #   /|\
    #  / | \
    # /  |  \
    # A--C--D
    #
    # *** Longueurs ***
    # AC       = base/2
    # BC       = hauteur
    # AB²      = AC² + BC²
    #
    # *** Angles ***
    # tan(ABC) = AC/BC
    # BAC      = 180-90-ABC
    # ABD      = 2 * ABC
    
    # Calcul des longueurs
    ac = base / 2
    bc = hauteur
    ab = math.sqrt(ac**2 + bc**2)
    
    # Calcul des angles
    angle_abc = math.degrees(math.atan(ac/bc))
    # angle_bac = ...
    # angle_abd = ...

    # Déplacement de la tortue
    # turtle.right(..)
    # turtle.forward(..)
    # turtle.right(..)
    # turtle.forward(..)
    # turtle.right(...)
    turtle.forward(base)
    turtle.right(90)


def maison():
    """
    Dessine une maison depuis le coin inférieur gauche dans le sens horaire.
    """
    pass


def dessiner_paysage():
    """Dessine un paysage de 3 maisons sous Turtle."""
    pass


# Tests
if __name__ == "__main__":
    aide.grille()
    
    turtle.pu()
    turtle.goto(-300, 0)
    turtle.setheading(90)
    turtle.pd()
    
    mur(200, 100)
    
    turtle.pu()
    turtle.goto(-300, 150)
    turtle.setheading(90)
    turtle.pd()
    
    toit(200, 50)

    turtle.pu()
    turtle.goto(0, 0)
    turtle.setheading(77)
    turtle.pd()
    maison()
    
    turtle.mainloop()